Node_t* search(Node_t* first,const char *wordToSearch)
{
 Node_t* temp = first;
 while (temp != NULL)
 {
 if (strcmp(temp->data.word, wordToSearch) == 0)
 break;
 temp = temp->link;
 }
 return temp;
}