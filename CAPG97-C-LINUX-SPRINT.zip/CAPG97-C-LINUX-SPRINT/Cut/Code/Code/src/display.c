void display(Node_t *first)
{
	Node_t* temp = first;
	//printf("%p-->" , temp);
	while (temp != NULL)
	{
		printf("[%10s	%20s] \n", temp->data.word, temp->data.meaning);
		temp = temp->link;
	}
}